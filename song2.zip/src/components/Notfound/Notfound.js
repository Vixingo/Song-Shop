import React from "react";

function Notfound() {
    return <div>Nothing is here</div>;
}

export default Notfound;
