import React from "react";

function MyPlaylists() {
    return <div>MyPlaylists</div>;
}

export default MyPlaylists;
