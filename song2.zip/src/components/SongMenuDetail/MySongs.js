import React from "react";

function MySongs() {
    return <div>MySongs</div>;
}

export default MySongs;
